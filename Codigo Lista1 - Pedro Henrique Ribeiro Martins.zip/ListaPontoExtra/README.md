# Atividades PO
README criado para informações sobre a execução dos arquivos da Atividade de Pesquisa Operacional
Sistema operacional utilizado: Ubuntu 22.04.1 LTS 64 bits
Versão do Python: Python 3.10.6

Observações:
Para a execução correta da questão 09 é necessário que os arquivos que serão lidos estejam no mesmo diretório que o arquvivo com o código.
Para a execução correta da questão 10 é necessário instalar a biblioteca jellyfish, através do comando 'pip install jellyfish'.
